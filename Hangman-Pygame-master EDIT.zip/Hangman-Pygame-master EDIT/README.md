# Hangman-Pygame

A game, python program, to increase your vocabulary.  

Requiremnts
* Python 3.4

```sh
$ sudo apt-get python3
```
Python Packages
 * Install pip

 ```sh
$ sudo apt-get install python3-pip
```

 * Pygame
  
 ```sh
 $ sudo pip3 install pygame
 ```
 
