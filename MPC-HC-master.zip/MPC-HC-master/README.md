# MPC-HC
We have made some modifications in media player classic and we hope this would be more friendly with you .
<img src="https://raw.githubusercontent.com/itsurboydheerajkamble/MPC-HC/master/Logo/08.png" width="500" height="500">

Changes Made 
1) Icon
2) Interface
3) Marathi and Hindi Language (Basics)
4) Logo 

 Icons , Logo are designed by us via photoshop , also buttons are edited by us.
 
 Feedback is appreciated .
 In case of any queries mail us on - "www.breakkebaad@gmail.com"
 
 May follow us on LinkedIn OR may subscribe our official YOUTUBE channel 
 https://www.linkedin.com/in/dheeraj-kamble-752301120/
 https://www.youtube.com/c/DheerajKambleOfficial
 
 
 May also download from the links dropped below :
 Drive Link -
 https://drive.google.com/open?id=1IlsQY24OuF27qFtLDHJ4XrxiM-AG-P49
Mediafire_link -
https://www.mediafire.com/file/dm1n5k2a3jteyez/dv+player+classic_ori.7z

Submitted by - Dheeraj Anand Kamble |
               Vishwajit Shelke
               
